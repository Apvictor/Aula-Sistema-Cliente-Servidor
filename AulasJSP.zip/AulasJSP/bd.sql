create database Mercado;

use Mercado;

create table tabProduto(
	codigo_produto int auto_increment primary key,
    descricao_produto varchar(100) not null,
    preco_produto double not null
);

drop table tabProduto;