import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * @author Armando
 */
public class Compra extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            int f1,f2,f3;
            int r1,r2,r3;
            int l1,l2,l3;
          
            float resultado = 0, total = 0;
            
            String[] produtos = request.getParameterValues("produto");
            
            for(String prod : produtos){
                switch (prod) {
                    //FOGÃO
                    case "Fogao Consul":
                        f1 = Integer.parseInt(request.getParameter("quantFogao1"));
                        resultado = f1 * 549.90f;
                        break;
                    case "Fogao Brastemp":
                        f2 = Integer.parseInt(request.getParameter("quantFogao2"));
                        resultado = f2 * 999.90f;
                        break;
                    case "Fogao Electrolux":
                        f3 = Integer.parseInt(request.getParameter("quantFogao3"));
                        resultado = f3 * 1199.90f;
                        break;
                    //REFRIGERADOR    
                    case "Refrigerador Brastemp":
                        r1 = Integer.parseInt(request.getParameter("quantRefrigerador1"));
                        resultado = r1 * 2299.90f;
                        break;
                    case "Refrigerador Consul":
                        r2 = Integer.parseInt(request.getParameter("quantRefrigerador2"));
                        resultado = r2 * 1099.90f;
                        break;
                    case "Refrigerador Electrolux":
                        r3 = Integer.parseInt(request.getParameter("quantRefrigerador3"));
                        resultado = r3 * 1849.90f;
                        break;
                    //LAVADORA
                    case "Lavadora de Roupas Brastemp 11kg":
                        l1 = Integer.parseInt(request.getParameter("quantLavadora1"));
                        resultado = l1 * 1295.89f;
                        break;
                    case "Lavadora de Roupas Electrolux 12kg":
                        l2 = Integer.parseInt(request.getParameter("quantLavadora2"));
                        resultado = l2 * 1099.90f;
                        break;
                    case "Lavadora de Roupas Electrolux 15kg":
                        l3 = Integer.parseInt(request.getParameter("quantLavadora3"));
                        resultado = l3 * 1099.90f;
                        break;
                    //FIM
                    default:
                        System.err.println("Falha!");
                        break;
                }
                total += resultado;
                out.println("<center><b>Produto: </b>" + prod + "<br> <b>Valor(R$): </b>" + resultado + "<br><br></center>");
            }
                                  
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Compras</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<center><h2>Total R$ " + total + "</h2></center>");  
            out.println("<center><input type='button' name='voltar' value='Voltar' onClick='javaScript:history.back(1)'></center>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}

